=== WP Job Portal by Jane ===
Contributors: Janehires.com
Tags: job portal, careers, jobs, human resources
Requires at least: 4.0
Tested up to: 4.7.1
Stable tag: trunk

The easiest way to manage your organization's open positions and all your resumes. Display your jobs on a careers page!

== Description ==

WP Job Portal displays your jobs on your careers page and then funnels applicants and their resumes into your very own applicant tracking system.



== Installation ==

1. Upload the plugin files to the `/wp-content/plugins/WP-Job-Portal-by-Jane` directory, or install the plugin through the WordPress plugins screen directly.
2. Activate the plugin through the 'Plugins' screen in WordPress
3. During the plugin setup, create a new Janehires.com account, or use your existing account
4. Use the Settings->WP Job Portal by Jane screen to manage the plugin, invite users to your Janehires.com account, and create new jobs


== Upgrade Notice ==
= 1.0 =
This is the first version of the plugin!

= 2.2 =
+ Added ability to create and edit jobs right in WordPress
+ Added shortcode for standalone job pages
+ Added job management tools
+ Added public/private toggle for jobs

== API ==

The WP Job Portal by Jane plugin uses the features of Janehires.com through its own API.

If specified during plugin setup, the API will create a new Janehires account for you.

Once installed, the plugin will use the API to display your company's jobs within: a careers page, a widget, and a shortcode - all of which is fully customizable by you.

